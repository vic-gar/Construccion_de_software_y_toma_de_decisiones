const Personaje = require('../src/personaje');

describe('Personaje', () => {
  let heroe;

  beforeEach (() => {
    heroe = new Personaje('Aria', 100, 15, 5);
  });

  test('Personaje recien creado tiene vida completa', () => {
    expect(heroe.vidaActual).toBe(heroe.vidaMaxima);
  });

  test('recibirDanio reduce correctamente la vida', () => {
    heroe.recibirDanio(30);
    expect(heroe.vidaActual).toBe(70);
  });

  test('recibirDanio con danio letal deja vida en 0', () => {
    heroe.recibirDanio(100);
    expect(heroe.vidaActual).toBe(0);
  });

  test('recibirDanio con valor negativo lanza error', () => {
    expect(() => heroe.recibirDanio(-10)).toThrow();
  });

  test('curar aumenta vida correctamente', () => {
    heroe.recibirDanio(40);
    heroe.curar(20);
    expect(heroe.vidaActual).toBe(80);
  });

  test('curar no extiende la vida máxima', () => {
    heroe.recibirDanio(60);
    heroe.curar(200);
    expect(heroe.vidaActual).toBe(heroe.vidaMaxima);
  });

  test('estaVivo retorna true si vida es mayor a 0', () => {
    expect(heroe.estaVivo()).toBeTruthy();
  });

  test('estaVivo retorna false si vida es menor a 0', () => {
    heroe.recibirDanio(100);
    expect(heroe.estaVivo()).toBeFalsy();
  });

});