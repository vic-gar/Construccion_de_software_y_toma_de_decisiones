const { calcularDanio } = require('../src/combate');

describe('Combate', () => {
    test('daño normal: ataque mayor que defensa', () => {
    // Arrange
    const a = { ataque: 15 };
    const d = { defensa: 5 };

    // Act
    const danio = calcularDanio(a, d);

    // Assert
    expect(danio).toBe(10);
    });

    test('daño cuando ataque es igual a defensa', () => {
        const a = { ataque: 15 };
        const d = { defensa: 15 };

        const danio = calcularDanio(a, d);

        expect(danio).toBe(1);
    });

    test('daño cuando ataque es menor a defensa', () => {
        const a = { ataque: 5 };
        const d = { defensa: 15 };

        const danio = calcularDanio(a, d);

        expect(danio).toBe(1);
    });

    test('daño cuando ataque y defensa son 0', () => {
        const a = { ataque: 0 };
        const d = { defensa: 0 };

        const danio = calcularDanio(a, d);

        expect(danio).toBe(1);
    });
});