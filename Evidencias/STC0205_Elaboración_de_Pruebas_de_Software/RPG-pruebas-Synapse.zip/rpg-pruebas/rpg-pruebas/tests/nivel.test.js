const { calcularRecompensa } = require('../src/nivel');

describe('Nivel', () => {
    test('mismo nivel: multiplicador 1.0', () => {
    // Arrange
    const xpBase = 100;
    const nivelEnemigo = 5;
    const nivelPersonaje = 5;

    // Act
    const xp = calcularRecompensa(xpBase, nivelEnemigo, nivelPersonaje);

    // Assert
    expect(xp).toBe(100);
    });

    test('enemigo 3 o más niveles abajo', () => {
    const xpBase = 100;
    const nivelEnemigo = 2;
    const nivelPersonaje = 5;

    const xp = calcularRecompensa(xpBase, nivelEnemigo, nivelPersonaje);

    expect(xp).toBe(50);
    });

    test('enemigo 1 o 2 niveles abajo', () => {
    const xpBase = 100;
    const nivelEnemigo = 4;
    const nivelPersonaje = 5;

    const xp = calcularRecompensa(xpBase, nivelEnemigo, nivelPersonaje);

    expect(xp).toBe(75);
    });

    test('enemigo 1 o 2 niveles arriba', () => {
    const xpBase = 100;
    const nivelEnemigo = 5;
    const nivelPersonaje = 3;

    const xp = calcularRecompensa(xpBase, nivelEnemigo, nivelPersonaje);

    expect(xp).toBe(150);
    });

    test('enemigo 3 o más niveles arriba', () => {
    const xpBase = 100;
    const nivelEnemigo = 8;
    const nivelPersonaje = 5;

    const xp = calcularRecompensa(xpBase, nivelEnemigo, nivelPersonaje);

    expect(xp).toBe(200);
    });

});
